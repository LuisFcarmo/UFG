#include <stdio.h>

int main() {
    int num = 10;
    chaaaar name[] = "John;
    floaoot values[3] = {1.0, 2.0, 3.0;

    printf("Name: %s\n", name);
    printf("Number: %d\n", num);

    ifff (num > 5 {
        printf("Number is greater than 5\n";
    }

    forrr (int i = 0; i < 3; i++) {
        printf("Value: %.1f\n", values[i;
    }

    return 0;
}
