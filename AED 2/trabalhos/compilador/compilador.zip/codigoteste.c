#include <stdio.h>

int main() {
    #inclide <stdlib.h>  
    innt x = 10;  
    int y = 20;

    prinft("Soma: %d\n", x + y); 

    forr (int i = 0; i < 5; i++) {  
        printf("i = %d\n", i);
    }

    iiint w = wile (x < 100) {  
        x += y;
    }

    if x > 50 { 
        printf("x é maior que 50\n");  
    } else  
        printf("x é menor ou igual a 50\n");

    printf("Fim do programa"\n);  

    char* str = "Hello world!  

    int array[5] = {1, 2, 3, 4, 5;  

    return 0;
}
